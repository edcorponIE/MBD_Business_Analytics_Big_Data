# this package is necessary to get input from Excel
install.packages(readxl)
library(readxl)

provinces <- as.data.frame(read_excel("provinces.xlsx"))


# this is correlation matrix and you can just type View(correlation_matrix)
correlation_matrix <- cor(provinces[,-1])

# code below is just to get the unique pairs of columns with corresponding values in descending order
correlated_cols <- data.frame(column_pair = character(), correlation = numeric())

for (col in colnames(correlation_matrix)) {
  for (row in rownames(correlation_matrix)) {
    if (abs(correlation_matrix[row,col]) >= 0.7 && abs(correlation_matrix[row,col]) != 1) {
        col_pair <- sort(c(row,col))
        col_pair <- sprintf('%s-%s', col_pair[1], col_pair[2])
        new_row <- data.frame(column_pair = col_pair, correlation = correlation_matrix[row,col])
        correlated_cols <- rbind(correlated_cols, new_row)
    }
  }
}

correlated_cols <- unique(correlated_cols)
correlated_cols <- correlated_cols[order(correlated_cols$correlation, decreasing =  TRUE),]
row.names(correlated_cols) <- NULL
View(correlated_cols)

# this package for nice beautiful chart of correlation matrix 
install.packages("corrplot")
library(corrplot)
corrplot(correlation_matrix)

